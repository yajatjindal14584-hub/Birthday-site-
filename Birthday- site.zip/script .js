let step = 0;
let photoIndex = 0;

let photos = [
  "photos/1.jpg",
  "photos/2.jpg",
  "photos/3.jpg",
  "photos/4.jpg",
  "photos/5.jpg"
];

const screens = [
  {
    title: "Hey you 👀, yes you chipkali 🦎",
    text: "I wanted to do something different for you today."
  },
  {
    title: "It’s your happy-vala birthday 🎂",
    text: "And I didn’t want to send just another text."
  },
  {
    title: "You’re not just special.",
    text: "You’re my kind of special. You’re my bestest friend ❤️"
  },
  {
    title: "Thank you 💛",
    text: "For being my comfort, my constant, my safe space."
  },
  {
    title: "Let’s just admire your beauty first 🤌🏻❤️",
    text: "",
    photo: true
  }
];

function next() {
  const title = document.getElementById("title");
  const text = document.getElementById("text");
  const photo = document.getElementById("photo");

  if (step < screens.length) {
    title.innerText = screens[step].title;
    text.innerText = screens[step].text || "";
    photo.style.display = "none";

    if (screens[step].photo) {
      photoIndex = 0;
      photo.style.display = "block";
      showPhotosOneByOne(photo);
    }

    step++;
  } else {
    document.querySelector(".card").innerHTML = `
      <h1>Happpyyyy Birthdayyy 🦎🎂❤️</h1>
      <p>
        I hope this made you smile,<br><br>
        because your smile means more to me than you know 🤍
      </p>
    `;
  }
}

function showPhotosOneByOne(photoElement) {
  photoElement.src = photos[photoIndex];

  let interval = setInterval(() => {
    photoIndex++;
    if (photoIndex >= photos.length) {
      clearInterval(interval);
      return;
    }
    photoElement.src = photos[photoIndex];
  }, 2500);
}